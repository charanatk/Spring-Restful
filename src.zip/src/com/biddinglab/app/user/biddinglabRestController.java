package com.biddinglab.app.user;

import org.apache.log4j.Logger;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/user")
public class biddinglabRestController {

	// Logger instance
	private static final Logger logger = Logger.getLogger(biddinglabRestController.class);

	@RequestMapping(value = "/get", method = RequestMethod.GET,produces = "application/json",headers="Accept=application/xml, application/json")
	public @ResponseBody userBean getSomething() {
		String request = "myreq";
		int version = 1;
		
		if (logger.isDebugEnabled()) {
			logger.debug("Start getSomething");
			logger.debug("data: '" + request + "'");
		}

		String response = "charan";
		userBean user = new userBean();
		user.setContent(response);
		user.setId(version);
		try {
			switch (version) {
			case 1:
				if (logger.isDebugEnabled())
					logger.debug("in version 1");
				// TODO: add your business logic here
				response = "Response from Spring RESTful Webservice : "+ request;

				break;
			default:
				throw new Exception("Unsupported version: " + version);
			}
		} catch (Exception e) {
			response = e.getMessage().toString();
		}

		if (logger.isDebugEnabled()) {
			logger.debug("result: '" + response + "'");
			logger.debug("End getSomething");
		}
		return user;
	}
}
